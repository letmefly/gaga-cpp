#include "gaga_client.h"
#include "gaga_util.h"

static GagaClient* g_GagaClientInstance = nullptr;
GagaClient* GagaClient::GetInstance() {
	if (nullptr == g_GagaClientInstance) {
		g_GagaClientInstance = new GagaClient();
	}
	return g_GagaClientInstance;
}

bool GagaClient::Connect() {
	RakNet::RakNetStatistics *rss;
	// Pointers to the interfaces of our server and client.
	// Note we can easily have both in the same program
	m_rakPeer = RakNet::RakPeerInterface::GetInstance();
	char *ip = "127.0.0.1";
	char *serverPort = "8989";
	char *clientPort = "7979";
	m_rakPeer->AllowConnectionResponseIPMigration(false);
	// Connecting the client is very simple.  0 means we don't care about
	// a connectionValidationInteger, and false for low priority threads
	RakNet::SocketDescriptor socketDescriptor(0, 0);
	socketDescriptor.socketFamily = AF_INET;
	m_rakPeer->Startup(8, &socketDescriptor, 1);
	m_rakPeer->SetOccasionalPing(true);
	RakNet::ConnectionAttemptResult ret = m_rakPeer->Connect(ip, atoi(serverPort), "fuck", (int)strlen("fuck"));
	RakAssert(ret == RakNet::CONNECTION_ATTEMPT_STARTED);

	return true;
}

void GagaClient::Disconnect() {
	RakNet::RakPeerInterface::DestroyInstance(m_rakPeer);
}

void GagaClient::Tick() {
	RakNet::Packet *packet;
	for (packet = m_rakPeer->Receive(); packet; m_rakPeer->DeallocatePacket(packet), packet = m_rakPeer->Receive()) {
		HandlePacket(packet);
	}
}

void GagaClient::HandlePacket(RakNet::Packet *packet) {
	RakNet::MessageID messageId = (unsigned char)(packet->data[0]);
	if (messageId == ID_NEW_INCOMING_CONNECTION) {
	}
	else if (messageId == ID_DETECT_LOST_CONNECTIONS) {

	}
	else if (messageId == ID_CONNECTION_REQUEST_ACCEPTED) {
		m_serverAddr = packet->systemAddress;
	}
	else if (messageId >= proto::MSG_RESERVE) {
		if (!m_msgHandler) return;
		if (messageId == proto::MSG_LOGIN_ACK) {
			printf("login ack");
			proto::Login_ack login_ack;
			GagaUtil::GetInstance()->ParseMsg(packet, login_ack);
			m_msgHandler->on_login_ack(login_ack);
		}
		else if (messageId == proto::MSG_JOIN_ROOM_ACK) {
			proto::JoinRoom_ack joinRoom_ack;
			GagaUtil::GetInstance()->ParseMsg(packet, joinRoom_ack);
			m_msgHandler->on_joinRoom_ack(joinRoom_ack);
		}
		else if (messageId == proto::MSG_LIST_ROOM_ACK) {
			proto::ListRoom_ack listRoom_ack;
			GagaUtil::GetInstance()->ParseMsg(packet, listRoom_ack);
			m_msgHandler->on_listRoom_ack(listRoom_ack);
		}
		else if (messageId == proto::MSG_PLAYER_LIST_NTF) {
			proto::PlayerList_ntf playerList_ntf;
			GagaUtil::GetInstance()->ParseMsg(packet, playerList_ntf);
			m_msgHandler->on_playerList_ntf(playerList_ntf);
		}
		else if (messageId == proto::MSG_ENTER_GAME_NTF) {
			proto::EnterGame_ntf enterGame_ntf;
			GagaUtil::GetInstance()->ParseMsg(packet, enterGame_ntf);
			m_msgHandler->on_enterGame_ntf(enterGame_ntf);
		}
		else if (messageId == proto::MSG_START_RACE_NTF) {
			proto::StartRace_ntf startRace_ntf;
			GagaUtil::GetInstance()->ParseMsg(packet, startRace_ntf);
			m_msgHandler->on_startRace_ntf(startRace_ntf);
		}
		else if (messageId == proto::MSG_LOGIC_FRAME_NTF) {
			proto::LogicFrame_ntf logicFrame_ntf;
			GagaUtil::GetInstance()->ParseMsg(packet, logicFrame_ntf);
			m_msgHandler->on_logicFrame_ntf(logicFrame_ntf);
		}
	}
}

void GagaClient::SendMsg(const RakNet::MessageID msgId, const ::google::protobuf::MessageLite& msg) {
	GagaUtil::GetInstance()->SendMsg(m_rakPeer, m_serverAddr, msgId, msg);
}


