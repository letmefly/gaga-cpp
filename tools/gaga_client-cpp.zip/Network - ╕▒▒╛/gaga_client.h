#ifndef __GAGA_CLIENT_H__
#define __GAGA_CLIENT_H__

#include "MessageIdentifiers.h"
#include "RakPeerInterface.h"
#include "RakNetStatistics.h"
#include "RakNetTypes.h"
#include "BitStream.h"
#include "RakSleep.h"
#include "PacketLogger.h"
#include "GameMsg.pb.h"

class GagaMsgHandler {
public:
	virtual void on_login_ack(const proto::Login_ack &msg) {}
	virtual void on_createRoom_ack(const proto::CreateRoom_ack &msg) {}
	virtual void on_joinRoom_ack(const proto::JoinRoom_ack &msg) {}
	virtual void on_listRoom_ack(const proto::ListRoom_ack &msg) {}
	virtual void on_playerList_ntf(const proto::PlayerList_ntf &msg) {}
	virtual void on_enterGame_ntf(const proto::EnterGame_ntf &msg) {}
	virtual void on_startRace_ntf(const proto::StartRace_ntf &msg) {}
	virtual void on_logicFrame_ntf(const proto::LogicFrame_ntf &msg) {}
};

class GagaClient
{
public:
	static GagaClient* GetInstance();
	GagaClient() {};
	~GagaClient() {};

	bool Connect();
	void Disconnect();
	void Tick();
	void SendMsg(const RakNet::MessageID msgId, const ::google::protobuf::MessageLite& msg);
	void SetMsgHandler(GagaMsgHandler *msgHandler) { m_msgHandler = msgHandler; }

private:
	void HandlePacket(RakNet::Packet *packet);
	RakNet::RakPeerInterface *m_rakPeer;
	RakNet::SystemAddress m_serverAddr;
	GagaMsgHandler *m_msgHandler;
};


#endif