// by pvp chris.li
#include "VuPurple/Util/VuGameUtil.h"
#include "VuEngine/Entities/VuEntity.h"
#include "VuEngine/Components/Script/VuScriptComponent.h"
#include "VuEngine/Properties/VuEnumProperty.h"
#include "VuEngine/Properties/VuAssetProperty.h"
#include "VuEngine/Assets/VuAssetFactory.h"
#include "VuEngine/Assets/VuProjectAsset.h"
#include "VuEngine/Managers/VuTickManager.h"
#include "VuEngine/HAL/GamePad/VuGamePad.h"
#include "VuEngine/Util/VuStringUtil.h"
#include "VuPurple/Util/CommonUtility.h"
#include "VuEngine/Properties/VuDBEntryProperty.h"

#if defined VUANDROID || defined VUIOS
#include "VuEngine/Util/VuLog.h"
#else
#include "VuEngine/Prefix/VuDebugSettings.h"
#endif

// by pvp chris.li
#include "VuPurple/Network/gaga_client.h"
#include "VuPurple/Pvp/VuPvpManager.h"
#include "VuEngine/Assets/VuSpreadsheetAsset.h"
#include "VuEngine/Assets/VuProjectAsset.h"
#include "VuEngine/Events/VuEventManager.h"

//*****************************************************************************
// VuPvpRoomEntity
//*****************************************************************************
class VuPvpRoomEntity : public VuEntity, public GagaMsgHandler
{
	DECLARE_RTTI

public:
	VuPvpRoomEntity();
	~VuPvpRoomEntity();
	void TickDecision(float fdt);

	// network request
	void do_listRoom_req(proto::ListRoom_req &listRoom_req);
	void do_joinRoom_req(proto::JoinRoom_req &joinRoom_req);

	// msg handlers
	virtual void on_login_ack(const proto::Login_ack &msg);
	virtual void on_createRoom_ack(const proto::CreateRoom_ack &msg);
	virtual void on_joinRoom_ack(const proto::JoinRoom_ack &msg);
	virtual void on_listRoom_ack(const proto::ListRoom_ack &msg);
	virtual void on_playerList_ntf(const proto::PlayerList_ntf &msg);
	virtual void on_enterGame_ntf(const proto::EnterGame_ntf &msg);

	void RefreshUi();
private:
	VuRetVal			In(const VuParams &params);

	VuRetVal			TestLogin(const VuParams &params);
	VuRetVal			TestLogin1(const VuParams &params);
	VuRetVal			TestLogin2(const VuParams &params);
	VuRetVal			TestLogin3(const VuParams &params);
	VuRetVal			TestLogin4(const VuParams &params);
	VuRetVal			TestLogin5(const VuParams &params);

	void				DoTestLogin(std::string userid);

	// components
	VuScriptComponent	*mpScriptComponent;

	// properties
	int					mViewport;

	std::string			mUserid;
};

IMPLEMENT_RTTI(VuPvpRoomEntity, VuEntity);
IMPLEMENT_ENTITY_REGISTRATION(VuPvpRoomEntity);

//*****************************************************************************
VuPvpRoomEntity::VuPvpRoomEntity() :
mViewport(0)
{
	// properties
	addProperty(new VuIntProperty("Viewport", mViewport));

	// components
	addComponent(mpScriptComponent = new VuScriptComponent(this, 100));

	// scripting
	ADD_SCRIPT_INPUT_NOARGS(mpScriptComponent, VuPvpRoomEntity, In);
	ADD_SCRIPT_INPUT_NOARGS(mpScriptComponent, VuPvpRoomEntity, TestLogin);
	ADD_SCRIPT_INPUT_NOARGS(mpScriptComponent, VuPvpRoomEntity, TestLogin1);
	ADD_SCRIPT_INPUT_NOARGS(mpScriptComponent, VuPvpRoomEntity, TestLogin2);
	ADD_SCRIPT_INPUT_NOARGS(mpScriptComponent, VuPvpRoomEntity, TestLogin3);
	ADD_SCRIPT_INPUT_NOARGS(mpScriptComponent, VuPvpRoomEntity, TestLogin4);
	ADD_SCRIPT_INPUT_NOARGS(mpScriptComponent, VuPvpRoomEntity, TestLogin5);

	GagaClient::GetInstance()->SetMsgHandler(this);
}

VuPvpRoomEntity::~VuPvpRoomEntity() {
	VuTickManager::IF()->unregisterHandler(this, "Decision");
	GagaClient::GetInstance()->SetMsgHandler(nullptr);
}


//*****************************************************************************
VuRetVal VuPvpRoomEntity::In(const VuParams &params)
{
	VuTickManager::IF()->registerHandler(this, &VuPvpRoomEntity::TickDecision, "Decision");
	int place = 0;
	// by pvp chris.li
	GagaClient::GetInstance()->Connect();
	return VuRetVal();
}

//*****************************************************************************
VuRetVal VuPvpRoomEntity::TestLogin(const VuParams &params)
{
	DoTestLogin("testuser_0");
	return VuRetVal();
}
VuRetVal VuPvpRoomEntity::TestLogin1(const VuParams &params)
{
	DoTestLogin("testuser_1");
	return VuRetVal();
}
VuRetVal VuPvpRoomEntity::TestLogin2(const VuParams &params)
{
	DoTestLogin("testuser_2");
	return VuRetVal();
}
VuRetVal VuPvpRoomEntity::TestLogin3(const VuParams &params)
{
	DoTestLogin("testuser_3");
	return VuRetVal();
}
VuRetVal VuPvpRoomEntity::TestLogin4(const VuParams &params)
{
	DoTestLogin("testuser_4");
	return VuRetVal();
}
VuRetVal VuPvpRoomEntity::TestLogin5(const VuParams &params)
{
	DoTestLogin("testuser_5");
	return VuRetVal();
}

void VuPvpRoomEntity::DoTestLogin(std::string userid) {
	VuPvpManager::GetInstance()->SetMyUserid(userid);
	mUserid = userid;
	proto::Login_req login_req;
	proto::User_t* userInfo = login_req.mutable_userinfo();
	userInfo->set_userid(userid.c_str());
	userInfo->set_nickname(userid.c_str());
	GagaClient::GetInstance()->SendMsg(proto::MSG_LOGIN_REQ, login_req);
}

void VuPvpRoomEntity::TickDecision(float fdt) {
	// by pvp chris.li
	GagaClient::GetInstance()->Tick();
}

void VuPvpRoomEntity::do_listRoom_req(proto::ListRoom_req &listRoom_req) {
	GagaClient::GetInstance()->SendMsg(proto::MSG_LIST_ROOM_REQ, listRoom_req);
}

void VuPvpRoomEntity::do_joinRoom_req(proto::JoinRoom_req &joinRoom_req) {
	GagaClient::GetInstance()->SendMsg(proto::MSG_JOIN_ROOM_REQ, joinRoom_req);
}

void VuPvpRoomEntity::on_login_ack(const proto::Login_ack &msg) {
	VUPRINTF("on_login_ack\n");
	proto::ListRoom_req listRoom_req;
	listRoom_req.set_offset(0);
	do_listRoom_req(listRoom_req);
}

void VuPvpRoomEntity::on_createRoom_ack(const proto::CreateRoom_ack &msg) {

}

void VuPvpRoomEntity::on_joinRoom_ack(const proto::JoinRoom_ack &msg) {
	if (msg.error_code() == proto::CODE_OK) {
		VUPRINTF("on_joinRoom_ack\n");
		VuPvpManager::GetInstance()->SetMyPlayerid(msg.playerid());
	}
}

void VuPvpRoomEntity::on_listRoom_ack(const proto::ListRoom_ack &msg) {
	VUPRINTF("on_listRoom_ack\n");
	for (auto room : msg.room_list()) {
		VUPRINTF("roomNo %ld\n", room.room_no());
	}
	proto::JoinRoom_req joinRoom_req;
	joinRoom_req.set_room_no(msg.room_list().Get(0).room_no());
	auto playerInfo = joinRoom_req.mutable_playerinfo();
	playerInfo->set_car_name("Buggy");
	playerInfo->set_paint_color("BrightRed");
	playerInfo->set_handling(0);
	playerInfo->set_driver_type("Human");
	playerInfo->set_decal("Flames");
	playerInfo->set_accel(0);
	playerInfo->set_stage(0);
	playerInfo->set_driver_name("Rad");
	playerInfo->set_speed(0);
	playerInfo->set_decal_color("Yellow");
	playerInfo->set_tough(0);
	do_joinRoom_req(joinRoom_req);
}

void VuPvpRoomEntity::on_playerList_ntf(const proto::PlayerList_ntf &msg) {
	//VUPRINTF("on_playerList_ntf\n");
	for (int i = 0; i < msg.player_list_size(); i++) {
		auto playerInfo = msg.player_list().Get(i);
		Player tmpPlayer;
		tmpPlayer.set_playerid(playerInfo.playerid());
		tmpPlayer.set_car_name(playerInfo.car_name());
		tmpPlayer.set_is_free(playerInfo.is_free());
		tmpPlayer.set_is_owned(playerInfo.is_owned());
		tmpPlayer.set_stage(playerInfo.stage());
		tmpPlayer.set_decal(playerInfo.decal());
		tmpPlayer.set_decal_color(playerInfo.decal_color());
		tmpPlayer.set_driver_name(playerInfo.driver_name());
		tmpPlayer.set_driver_type(playerInfo.driver_type());
		tmpPlayer.set_accel(playerInfo.accel());
		tmpPlayer.set_speed(playerInfo.speed());
		tmpPlayer.set_handling(playerInfo.handling());
		tmpPlayer.set_tough(playerInfo.tough());
		tmpPlayer.set_is_gold(playerInfo.is_gold());
		tmpPlayer.set_min_stage(playerInfo.min_stage());
		tmpPlayer.set_max_stage(playerInfo.max_stage());
		tmpPlayer.set_paint_color(playerInfo.paint_color());
		VuPvpManager::GetInstance()->AddPlayer(tmpPlayer);
	}
}

void VuPvpRoomEntity::on_enterGame_ntf(const proto::EnterGame_ntf &msg) {
	// Now enter game with other players
	const VuSpreadsheetAsset *pSA = VuGameUtil::IF()->eventSpreadsheet();
	const VuFastContainer &row = pSA->getRow(1);
	std::string gameType = row[pSA->getColumnIndex("Type")].asCString();
	std::string trackName = row[pSA->getColumnIndex("Track")].asCString();
	std::string projectAsset = trackName + "_" + gameType;
	if (!VuAssetFactory::IF()->doesAssetExist<VuProjectAsset>(projectAsset))
		projectAsset = trackName + "_Race";

	VuJsonContainer &eventData = VuGameUtil::IF()->dataWrite()["EventData"];

	eventData["SeriesName"].putValue("SeriesA");
	eventData["EventName"].putValue("SeriesA_Event02");
	eventData["GameType"].putValue(gameType);
	eventData["ProjectAsset"].putValue(projectAsset);
	eventData["Track"].putValue(trackName);
	eventData["LapCount"].putValue(row[pSA->getColumnIndex("Laps")].asInt());
	eventData["TimeLimit"].putValue(row[pSA->getColumnIndex("Time")].asInt());
	eventData["IsChallenge"].putValue(false);
	eventData["IsPvp"].putValue(true);
	eventData["Opponents"].clear();

	VuParams outParams;
	outParams.addString("PvpEvent");
	VuEventManager::IF()->broadcast("OnStartActionGame", outParams);
}

void VuPvpRoomEntity::RefreshUi() {
	auto playerList = VuPvpManager::GetInstance()->GetPlayerList();
	for (int i = 0; i < 6; i++) {
		auto player = playerList.at(i);
		if (player) {
			//int32_t playerid = player->mPlayerid;
			// refresh ui here
		}
	}
}

