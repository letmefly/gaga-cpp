#include "VuPvpManager.h"

static VuPvpManager *g_pvpManager = nullptr;

VuPvpManager* VuPvpManager::GetInstance() {
	if (nullptr == g_pvpManager) {
		g_pvpManager = new VuPvpManager();
	}
	return g_pvpManager;
}

VuPvpManager::VuPvpManager() : mMyPlayerid(0), mPhase(0) {

}

VuPvpManager::~VuPvpManager() {

}

void VuPvpManager::AddPlayer(Player &player) {
	bool isFind = false;
	for (auto it : mPlayerList) {
		if (it->get_playerid() == player.get_playerid()) {
			isFind = true;
			break;
		}
	}
	if (!isFind) {
		auto newPlayer = new Player();
		newPlayer->set_playerid(player.get_playerid());
		newPlayer->set_playerid(player.get_playerid());
		newPlayer->set_car_name(player.get_car_name());
		newPlayer->set_is_free(player.get_is_free());
		newPlayer->set_is_owned(player.get_is_owned());
		newPlayer->set_stage(player.get_stage());
		newPlayer->set_decal(player.get_decal());
		newPlayer->set_decal_color(player.get_decal_color());
		newPlayer->set_driver_name(player.get_driver_name());
		newPlayer->set_driver_type(player.get_driver_type());
		newPlayer->set_accel(player.get_accel());
		newPlayer->set_speed(player.get_speed());
		newPlayer->set_handling(player.get_handling());
		newPlayer->set_tough(player.get_tough());
		newPlayer->set_is_gold(player.get_is_gold());
		newPlayer->set_min_stage(player.get_min_stage());
		newPlayer->set_max_stage(player.get_max_stage());
		newPlayer->set_paint_color(player.get_paint_color());
		mPlayerList.push_back(newPlayer);
	}
}

void VuPvpManager::RemvoePlayer(int32_t playerid) {
	Player *target = nullptr;
	for (auto it = mPlayerList.begin(); it != mPlayerList.end(); it++) {
		if ((*it)->get_playerid() == playerid) {
			mPlayerList.erase(it);
			delete (*it);
			break;
		}
	}
}

void VuPvpManager::ClearAllPlayer() {
	for (int i = 0; i < 6; i++) {
		auto player = mPlayerList.at(i);
		if (player) {
			delete player;
		}
	}
	mPlayerList.clear();
}

std::vector<Player*>& VuPvpManager::GetPlayerList() {
	return mPlayerList;
}

void VuPvpManager::StartWork() {
	GagaClient::GetInstance()->SetMsgHandler(this);
}

void VuPvpManager::StopWork() {
	GagaClient::GetInstance()->SetMsgHandler(nullptr);
}

void VuPvpManager::EnterGameOk() {
	proto::EnterGameOk_req enterGameOk_req;
	enterGameOk_req.set_playerid(mMyPlayerid);
	GagaClient::GetInstance()->SendMsg(proto::MSG_ENTER_GAME_OK_REQ, enterGameOk_req);
}

void VuPvpManager::on_startRace_ntf(const proto::StartRace_ntf &msg) {
	VUPRINTF("on_startRace_ntf");
	SetPhase(3);
}

void VuPvpManager::on_logicFrame_ntf(const proto::LogicFrame_ntf &msg) {
	//VUPRINTF("on_logicFrame_ntf");
	auto newLogicFrame = new LogicFrame();
	newLogicFrame->frameNo = msg.frame_no();
	for (auto command : msg.command_list()) {
		auto newCommand = new GameCommand();
		newCommand->commandType = command.command_type();
		newCommand->playerid = command.playerid();
		newCommand->intVar1 = command.intvar1();
		newCommand->intVar2 = command.intvar2();
		newCommand->intVar3 = command.intvar3();
		newCommand->strVar1 = command.strvar1();
		newCommand->strVar2 = command.strvar2();
		newCommand->strVar3 = command.strvar3();
		newLogicFrame->commandList.push_back(newCommand);
	}
	m_logicFrameList.push_back(newLogicFrame);
}


