#pragma once
#include "VuPurple/Network/gaga_util.h"
#include "VuPurple/Network/gaga_client.h"
enum PlayerState
{
	kPlayerNotReady,
	kPlayerReady,
	kPlayerEnterRoomOk,
	kPlayerRunning
};
class Player {
public:
	Player() {}
	~Player() {}
	//PROPERTY_DEF(RakNet::RakNetGUID, userGuid);
	PROPERTY_DEF(PlayerState, state);
	PROPERTY_DEF(std::string, userid);
	PROPERTY_DEF(uint32_t, playerid);
	PROPERTY_DEF(std::string, car_name);
	PROPERTY_DEF(int32_t, is_free);
	PROPERTY_DEF(int32_t, is_owned);
	PROPERTY_DEF(int32_t, stage);
	PROPERTY_DEF(std::string, decal);
	PROPERTY_DEF(std::string, decal_color);
	PROPERTY_DEF(std::string, driver_name);
	PROPERTY_DEF(std::string, driver_type);
	PROPERTY_DEF(int32_t, accel);
	PROPERTY_DEF(int32_t, speed);
	PROPERTY_DEF(int32_t, handling);
	PROPERTY_DEF(int32_t, tough);
	PROPERTY_DEF(int32_t, is_gold);
	PROPERTY_DEF(int32_t, min_stage);
	PROPERTY_DEF(int32_t, max_stage);
	PROPERTY_DEF(std::string, paint_color);
protected:

};

struct GameCommand {
	uint32_t commandType;
	uint32_t playerid;
	int32_t intVar1;
	int32_t intVar2;
	int32_t intVar3;
	std::string strVar1;
	std::string strVar2;
	std::string strVar3;
};

struct LogicFrame {
	uint32_t frameNo;
	std::vector<GameCommand*> commandList;
};

class VuPvpManager : public GagaMsgHandler {
public:
	static VuPvpManager* GetInstance();
	VuPvpManager();
	~VuPvpManager();
	void StartWork();
	void StopWork();

	std::vector<LogicFrame*>& GetLogicFrameList() { return m_logicFrameList; }

	void EnterGameOk();
	void AddPlayer(Player &player);
	void RemvoePlayer(int32_t playerid);
	void ClearAllPlayer();
	std::vector<Player*>& GetPlayerList();

	void SetMyUserid(std::string &userid) { mMyUserid = userid; }
	std::string& GetMyUserid() { return mMyUserid; }

	void SetMyPlayerid(int32_t playerid) { mMyPlayerid = playerid; }
	int32_t GetMyPlayerid() { return mMyPlayerid; }
	void SetPhase(int32_t p) { mPhase = p; }
	int32_t GetPhase() { return mPhase; }
	bool IsAllEnterGameOk() { return mPhase >= 3; }
	// msg handlers
	//virtual void on_login_ack(const proto::Login_ack &msg);
	//virtual void on_createRoom_ack(const proto::CreateRoom_ack &msg);
	//virtual void on_joinRoom_ack(const proto::JoinRoom_ack &msg);
	//virtual void on_listRoom_ack(const proto::ListRoom_ack &msg);
	//virtual void on_playerList_ntf(const proto::PlayerList_ntf &msg);
	//virtual void on_enterGame_ntf(const proto::EnterGame_ntf &msg);
	virtual void on_startRace_ntf(const proto::StartRace_ntf &msg);
	virtual void on_logicFrame_ntf(const proto::LogicFrame_ntf &msg);

private:
	std::string mMyUserid;
	int32_t mMyPlayerid;
	int32_t mPhase;
	std::vector<Player*> mPlayerList;
	std::vector<LogicFrame*> m_logicFrameList;
};

